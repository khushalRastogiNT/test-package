# Tesing Package creation.
> Containing a count_in_list function to count the occurances of a word in a list.